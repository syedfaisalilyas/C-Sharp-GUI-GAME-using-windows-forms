﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using EZInput;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SpaceShooter
{
    public partial class GameForm : Form
    {
        int score;
        int current = 4;
        List<PictureBox> playerFireslist = new List<PictureBox>();
        List<PictureBox> enemyFireslist = new List<PictureBox>();
        List<PictureBox> enemies = new List<PictureBox>();
        List<PictureBox> rewardslist = new List<PictureBox>();
        Random rand;
        PictureBox enemy1;
        PictureBox enemy2;
        PictureBox enemy3;
        PictureBox enemy4;
        int enemy1currentFireTime;
        int enemy2currentFireTime;
        int enemy3currentFireTime;
        int enemy4currentFireTime;
        int rewardcurrentTime;
        int enemy1TimeToGenerateFire;
        int enemy2TimeToGenerateFire;
        int enemy3TimeToGenerateFire;
        int enemy4TimeToGenerateFire;
        int rewardTimeToGenerate;
        int EnemySpeed;
        string enemy1direction = "down";
      
        public GameForm()
        {
            InitializeComponent();
        }

        private void timer_Tick(object sender, EventArgs e)
        {
            playermovement();
            enemyMovement(enemy1, ref enemy1direction);
            enemyMovement(enemy2, ref enemy1direction);
            enemyMovement(enemy3, ref enemy1direction);
            enemyMovement(enemy4, ref enemy1direction);
            fireBullet();
            removeBullet();
            detectCollison();
            enemy1currentFireTime++;
            enemy2currentFireTime++;
            enemy3currentFireTime++;
            enemy4currentFireTime++;
            rewardcurrentTime++;
            if (enemy1currentFireTime == enemy1TimeToGenerateFire)
            {
                Image Enemy1fire = SpaceShooter.Properties.Resources.laserRed09;
                if(enemy1.Visible == true)
                createEnemyBullet(Enemy1fire, enemy1);
                enemy1currentFireTime = 0;
            }
            if (enemy2currentFireTime == enemy2TimeToGenerateFire)
            {
                Image Enemy2fire = SpaceShooter.Properties.Resources.laserRed09 ;
                if (enemy2.Visible == true)
                    createEnemyBullet(Enemy2fire, enemy2);
                enemy2currentFireTime = 0;
            }
            if (enemy3currentFireTime == enemy3TimeToGenerateFire)
            {
                Image Enemy3fire = SpaceShooter.Properties.Resources.laserRed09;
                if (enemy3.Visible == true)
                    createEnemyBullet(Enemy3fire, enemy3);
                enemy3currentFireTime = 0;
            }
            if (enemy4currentFireTime == enemy4TimeToGenerateFire)
            {
                Image Enemy4fire = SpaceShooter.Properties.Resources.laserRed09;
                if (enemy4.Visible == true)
                    createEnemyBullet(Enemy4fire, enemy3);
                enemy4currentFireTime = 0;
            }
            if(rewardcurrentTime == rewardTimeToGenerate)
            {
                Image reward = SpaceShooter.Properties.Resources.laserBlue09;
                createReward(reward);
                rewardcurrentTime = 0;
            }
            setPositionofProgressBar();
            isGameWin();
            isGameOver();
        }
        private PictureBox createReward(Image img)
        {
            rand = new Random();
            PictureBox reward = new PictureBox();
            int left = rand.Next(30, this.Width); ;
            int top = rand.Next(5, img.Height + 20); ;
            reward.Left = left;
            reward.Top = top;
            reward.Height = img.Height;
            reward.Width = img.Width;
            reward.BackColor = Color.Transparent;
            reward.Image = img;
            addcontrolintoform(reward);
            addtolist(reward, rewardslist);
            return reward;
        }
        private void isGameWin()
        {
            if (enemies.Count == 0)
            {
                GameLoop.Enabled = false;
                Image img = SpaceShooter.Properties.Resources.WIN;
                GameOver form = new GameOver(img,score);
                DialogResult result = form.ShowDialog();
                if (result == DialogResult.Yes)
                {
                    GameFormLoad();
                }
                if (result == DialogResult.No)
                {
                    Application.Exit();
                }
                this.Close();
            }
        }

        private void GameFormLoad()
        {
            GameForm form = new GameForm();
            form.ShowDialog();
        }

        private void isGameOver()
        {
            if (HealthProgress.Value == 0)
            {
                GameLoop.Enabled = false;
                Image img = SpaceShooter.Properties.Resources.gameover;
                GameOver form = new GameOver(img,score);
                DialogResult result = form.ShowDialog();
                if (result == DialogResult.Yes)
                {
                    GameFormLoad();
                }
                if (result == DialogResult.No)
                {
                    Application.Exit();
                }
                this.Close();
            }
        }

        private void playermovement()
        {
            if (Keyboard.IsKeyPressed(Key.RightArrow) || Keyboard.IsKeyPressed(Key.D))
            {
                if ((player.Left + player.Width + 30 < this.Width))
                {
                    player.Left += EnemySpeed;
                }
            }
            if (Keyboard.IsKeyPressed(Key.LeftArrow) || Keyboard.IsKeyPressed(Key.A))
            {
                if (player.Left - 20 > 0)
                {
                    player.Left -= EnemySpeed;

                }
            }
            if (Keyboard.IsKeyPressed(Key.UpArrow) || Keyboard.IsKeyPressed(Key.W))
            {
                if (player.Top > 0)
                {
                    player.Top -= EnemySpeed;
                }
            }
            if (Keyboard.IsKeyPressed(Key.DownArrow) || Keyboard.IsKeyPressed(Key.S))
            {
                if (player.Top + player.Width + 30 < this.Height)
                {
                    player.Top += EnemySpeed;
                }

            }
            if (Keyboard.IsKeyPressed(Key.Space))
            {
                createBullet();
            }
        }

        private void createBullet()
        {
            Image playerfire = SpaceShooter.Properties.Resources.laserRed01;
            PictureBox playeerfire = firingSystem(playerfire, player);
            addtolist(playeerfire,playerFireslist);
            addcontrolintoform(playeerfire);
        }

        private void createEnemyBullet(Image img, PictureBox source)
        {
            PictureBox enemyFire = firingSystemEnemy(img, source);
            addtolist(enemyFire,enemyFireslist);
            addcontrolintoform(enemyFire);
        }
        private PictureBox firingSystemEnemy(Image fireImage, PictureBox source)
        {
            PictureBox Fire = new PictureBox();
            Fire.Image = fireImage;
            Fire.Width = fireImage.Width;
            Fire.Height = fireImage.Height;
            Fire.BackColor = Color.Transparent;
            Fire.Left = source.Left + 45;
            Fire.Top = source.Top + 60;
            return Fire;
        }

        private void detectCollison()
        {
            foreach (PictureBox fire in playerFireslist)
            {
                foreach (PictureBox enemy in enemies)
                {
                    if (fire.Bounds.IntersectsWith(enemy.Bounds))
                    {
                        current = 150;
                        score += 10;
                        enemies.Remove(enemy);
                        enemy.Visible = false;
                        fire.Visible = false;
                        this.Controls.Remove(enemy);
                        break;
                    }
                }

            }

            foreach(PictureBox enemy in enemies)
            {
                if(enemy.Bounds.IntersectsWith(player.Bounds))
                {
                    enemy1direction = "up";
                    if (HealthProgress.Value > 30)
                        HealthProgress.Value -= 30;
                    else
                        HealthProgress.Value = 0;
                }
            }

            foreach (PictureBox fire in enemyFireslist)
            {

                if (fire.Bounds.IntersectsWith(player.Bounds))
                {
                    if (HealthProgress.Value > 0)
                    {
                        HealthProgress.Value -= 10;
                        enemyFireslist.Remove(fire);
                        this.Controls.Remove(fire);
                        break;
                    }
                    else if (HealthProgress.Value == 0)
                    {
                        break;
                    }
                }
            }

            foreach (PictureBox reward in rewardslist)
            {

                if (reward.Bounds.IntersectsWith(player.Bounds))
                {
                    if (HealthProgress.Value > 0 )
                    {
                        if(HealthProgress.Value<100)
                        HealthProgress.Value += 10;
                        score += 10;
                        rewardslist.Remove(reward);
                        this.Controls.Remove(reward);
                        break;
                    }


                }

            }
        }

        private void addtolist(PictureBox source,List<PictureBox> list)
        {
            list.Add(source);
        }
        private void fireBullet()
        {
           foreach(PictureBox fire in playerFireslist)
            {
                fire.Top -= 15;
            }
           foreach(PictureBox fire in enemyFireslist)
            {
                fire.Top += 40;
            }
           foreach(PictureBox reward in rewardslist)
            {
                reward.Top += 30;
            }
          
        }
        private void removeBullet()
        {
            for (int i = 0; i < playerFireslist.Count; i++)
            {
                if (playerFireslist[i].Bottom < 0)
                {
                    playerFireslist.RemoveAt(i);
                }
            } 
            for (int i = 0; i < enemies.Count; i++)
            {
                if (enemies[i].Top >= this.Height || enemies[i].Visible == false)
                {
                    enemyFireslist.RemoveAt(i);
                }
            } 
            for (int i = 0; i < rewardslist.Count; i++)
            {
                if (rewardslist[i].Top >= this.Height || enemies[i].Visible == false)
                {
                    rewardslist.RemoveAt(i);
                }
            }

        }
        private PictureBox firingSystem(Image fireImage, PictureBox source)
        {
            PictureBox Fire = new PictureBox();
            Fire.Image = fireImage;
            Fire.Width = fireImage.Width;
            Fire.Height = fireImage.Height;
            Fire.BackColor = Color.Transparent;
            //Location/Point
            System.Drawing.Point fireLocation = new System.Drawing.Point();
            fireLocation.X = source.Left + (source.Width / 2) - 5;
            fireLocation.Y = source.Top-10;
            Fire.Location = fireLocation;
            return Fire;
        }
        private PictureBox createEnemy(Image img)
        {
            rand = new Random();
            PictureBox enemy = new PictureBox();
            enemy.Left = rand.Next(4, this.Width - img.Width);
            enemy.Top = rand.Next(4);
           /* current += 330;
            enemy.Left = current;
            enemy.Top = rand.Next(4); */
            enemy.Height = img.Height-50;
            enemy.Width = img.Width-50;
            enemy.SizeMode = PictureBoxSizeMode.StretchImage;
            enemy.BackColor = Color.Transparent;
            enemy.Image = img;
            return enemy;
        }


        private void GameForm_Load(object sender, EventArgs e)
        {
            enemy1 = createEnemy(SpaceShooter.Properties.Resources.enemy5);
            enemy2 = createEnemy(SpaceShooter.Properties.Resources.enemy4);
            enemy3 = createEnemy(SpaceShooter.Properties.Resources.enemy3);
            enemy4 = createEnemy(SpaceShooter.Properties.Resources.Enemy06);
            addcontrolintoform(enemy1);
            addcontrolintoform(enemy2);
            addcontrolintoform(enemy3);
            addcontrolintoform(enemy4);
            addtolist(enemy1, enemies);
            addtolist(enemy2, enemies);
            addtolist(enemy3, enemies);
            addtolist(enemy4, enemies);
            enemy1currentFireTime = 0;
            enemy2currentFireTime = 0;
            enemy3currentFireTime = 0;
            enemy4currentFireTime = 0;
            rewardcurrentTime = 0;
            enemy1TimeToGenerateFire = 120;
            enemy2TimeToGenerateFire = 90;
            enemy3TimeToGenerateFire = 60;
            enemy4TimeToGenerateFire = 60;
            rewardTimeToGenerate = 30;
            EnemySpeed = 20;
        }


        private void setPositionofProgressBar()

        {
            HealthProgress.Left = player.Left;
            HealthProgress.Top = player.Bottom;
        }
        private void enemyMovement(PictureBox enemy, ref string enemyDirection)
        {
            if (enemyDirection == "down")
            {
                enemy.Top += 10;
            }
            else if (enemyDirection == "up")
            {
                enemy.Top -= 10;
            }
            if (enemy.Top + enemy.Height > this.Height-20)
            {
                enemyDirection = "up";
            }
            if (enemy.Top <= 0)
            {
                enemyDirection = "down";
            }
        }
        private void addcontrolintoform(Control item)
        {
            this.Controls.Add(item);
        }
    }
}
