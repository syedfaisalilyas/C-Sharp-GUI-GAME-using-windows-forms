﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SpaceShooter
{
    public partial class GameOver : Form
    {
        int s;
        public GameOver(Image img,int score)
        {
            InitializeComponent();
            this.BackgroundImage = img;
            this.BackgroundImageLayout = ImageLayout.Stretch;
            s = score;
        }

        private void start_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Yes;
        }

        private void cancel_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.No;
        }


        private void GameOver_Load(object sender, EventArgs e)
        {
            score.Text = score.Text + s.ToString();
        }

      
        private void start_MouseEnter(object sender, EventArgs e)
        {
            start.BackColor = Color.Green;
        }

        private void start_MouseLeave(object sender, EventArgs e)
        {
            start.BackColor = Color.DarkGreen;

        }

        private void cancel_MouseEnter(object sender, EventArgs e)
        {
           cancel.BackColor = Color.Red;

        }

        private void cancel_MouseLeave(object sender, EventArgs e)
        {
            cancel.BackColor = Color.DarkRed;
        }

        private void score_Click(object sender, EventArgs e)
        {

        }
    }
}
